import request from '@/utils/request'

// post params形式
export function getParams (params) {
  return request({
    url: 'userinfo/vip/getVipInfo',
    method: 'post',
    params
  })
}

// get params形式
export function getData (data) {
  return request({
    url: 'material/videoInfoComment/addVideoInfoComment',
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    },
    method: 'post',
    data
  })
}
