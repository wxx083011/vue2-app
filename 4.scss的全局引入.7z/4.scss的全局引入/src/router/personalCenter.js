const personalCenter = r => require.ensure([], () => r(require('@/views/personalCenter/index')), 'personalCenter')
const bindInfo = r => require.ensure([], () => r(require('@/views/personalCenter/bindInfo')), 'bindInfo')
const personalDetails = r => require.ensure([], () => r(require('@/views/personalCenter/personalDetails')), 'personalDetails')

export default [
  {
    path: '/personalCenter',
    name: 'personalCenter',
    component: personalCenter
  },
  {
    path: '/bindInfo',
    name: 'bindInfo',
    component: bindInfo
  },
  {
    path: '/personalDetails',
    name: 'personalDetails',
    component: personalDetails
  }
]
