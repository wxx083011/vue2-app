<template>
  <div class="wrap center">
    <p>主页1</p>
    <div @click="$router.push({path: `/personalCenter`})">个人中心</div>
  </div>
</template>

<script>
import { getData, getParams } from '@/api/login'

export default {
  name: 'login',
  data () {
    return {}
  },
  components: {},
  created () {
    // // params形式
    // this.handleLogin()
    // // data形式
    // this.handleLogin1()
  },
  methods: {
    handleLogin1 () {
      let postData = {
        videoinfoid: 1,
        content: '评论了'
      }
      getData(JSON.stringify(postData))
        .then(res => {
          console.log(res)
        })
        .then(res => {
          // 同步请求
          console.log(1)
        })
        .then(res => {
          // 同步请求
          console.log(2)
        })
    },

    handleLogin () {
      let params = {
        vipLevel: 1
      }
      getParams(params).then(res => {
        console.log(res)
        // alert(response.data)
      })
    }
  }
}
</script>
<style lang="scss" >
p {
  color: color;
}
</style>
