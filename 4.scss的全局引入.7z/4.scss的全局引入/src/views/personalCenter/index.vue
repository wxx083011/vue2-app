<template>
 <div>
   <p>主业</p>
   <p @click="$router.push({path: `/login`})">个人中心</p>
   <div @click="$router.push({path: `/bindInfo`})">绑定信息</div>
   <div @click="$router.push({path: `/personalDetails`})">信息完善</div>
 </div>
</template>

<script>

export default {
  name: 'personalCenter',
  data () {
    return {
    }
  },
  components: {
  },
  created () {
  },
  methods: {
  }
}
</script>
<style >
 </style>
