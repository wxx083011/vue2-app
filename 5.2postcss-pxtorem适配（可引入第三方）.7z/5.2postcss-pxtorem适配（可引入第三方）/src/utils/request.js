import axios from 'axios'

// import store from '@/store'
// 创建axios实例
const service = axios.create({
  baseURL: 'http://t.szkbyj.com:8008/', // 服务器地址
  timeout: 15000 // 请求超时时间
})

// http request 请求拦截器，有token值则配置上token值
service.interceptors.request.use(
  config => {
    let token = sessionStorage.getItem('token') || ''
    if (token) { // 每次发送请求之前判断是否存在token，如果存在，则统一在http请求的header都加上token，不用每次请求都手动添加了
      config.headers.Authorization = token
    } else {
    }
    return config
  },
  err => {
    return Promise.reject(err)
  })

service.interceptors.response.use(
  function (response) {
    // 请求正常则返回
    try {
      return Promise.resolve(response)
    } catch (error) {
      console.log(error)
    }
  },
  function (error) {
    return Promise.reject(error)
  }
)

export default service
