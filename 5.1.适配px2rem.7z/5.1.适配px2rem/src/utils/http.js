/**
 * axios全局配置，包括验证签名及错误处理
 */

import axios from 'axios'
import store from '../store'
import qs from 'qs'
import { sign } from '../utils/sign'
import { Message } from 'element-ui'

function logout () {
  store.commit('setToken', '')
  store.commit('setAuthModules', '')
  window.location.reload()
}
// 超时设置
const service = axios.create({
  timeout: 600000 // 请求超时时间 60s
})

// http request 拦截器
// 每次请求都未http请求头增加token, 并生成sign
service.interceptors.request.use(
  config => {
    const token = store.state.token
    if (token) {
      config.data.token = token
    }
    config.data = qs.parse(config.data)
    // 定义生成签名后的data
    let data = sign(config.data)
    // 判断请求是否为get方式并格式化参数设置
    // if (config.method === 'get') {
    //   console.log(config.headers.isLoad)
    // }
    if (config.method === 'get' && config.headers.isLoad) {
      console.log('1')
      store.commit('setExportLoading', true)
      setTimeout(() => {
        console.log('2')
        store.commit('setExportLoading', false)
      }, 5000)
      config.url += '?' + qs.stringify(data)
      window.location.href = config.url
      return
    } else {
      config.data = JSON.stringify(data)
    }
    config.headers = {
      // 'Content-Type': 'application/x-www/form/urlencoded;charset=utf-8'
      // 'Content-Type': 'application/json;charset=utf-8'
    }
    return config
  },
  err => {
    return Promise.reject(err)
  }
)

// http response 拦截器
// 针对响应代码确认跳转到对应页面
service.interceptors.response.use(
  response => {
    if (response.data.responseCode === '0000') {
      return response.data
    } else if (response.data.responseCode === '1002') {
      Message.error({
        message: response.data.responseMsg,
        duration: store.state.duration
      })
    } else if (response.data.responseCode === '1004') {
      console.log(response.data.responseCode)
      Message.error({
        message: response.data.responseMsg + ',即将跳转至登录页...',
        duration: store.state.duration,
        onClose: () => {
          logout()
        }
      })
    } else if (response.data.responseCode === '1008') {
      console.log(response.data.responseCode)
      Message.error({
        message: response.data.responseMsg + ',即将跳转至登录页...',
        duration: store.state.duration,
        onClose: () => {
          logout()
        }
      })
    } else {
      return response.data
    }
  },
  error => {
    return Promise.reject(error)
  }
)

export default service
