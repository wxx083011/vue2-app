// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import '../src/assets/scss/common.scss'
import 'lib-flexible/flexible'
import axios from 'axios'
import QS from 'qs'

router.beforeEach((to, from, next) => {
  // if (to.matched.some(record => record.meta.requireAuth)) { // 判断该路由是否需要登录权限
  //   let token = sessionStorage.getItem('token') || ''
  //   if (!token) {
  //   /* 路由发生变化修改页面title */
  //     sessionStorage.setItem('token', '123')
  //     next({
  //       path: '/errors'
  //       // query: {redirect: to.fullPath} // 将要跳转路由的path作为参数，传递到登录页面
  //     })
  //   } else {
  //     if (to.meta.title) {
  //       document.title = to.meta.title
  //     }
  //     next()
  //   }
  // } else {
  //   next()
  // }
  let token = sessionStorage.getItem('token') || ''
  if (!token) {
    /* 路由发生变化修改页面title */
    sessionStorage.setItem('token', '123')
    next()
    // next({
    //   path: '/errors'
    //   // query: {redirect: to.fullPath} // 将要跳转路由的path作为参数，传递到登录页面
    // })
  } else {
    if (to.meta.title) {
      document.title = to.meta.title
    }
    next()
  }
  // next()
})

Vue.config.productionTip = false
Vue.prototype.$axios = axios
Vue.prototype.qs = QS

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  components: { App },
  template: '<App/>'
})
