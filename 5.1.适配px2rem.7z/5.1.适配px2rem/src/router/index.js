import Vue from 'vue'
import Router from 'vue-router'

import personalCenter from './personalCenter'
const login = r => require.ensure([], () => r(require('@/views/login/index')), 'login')
const errors = r => require.ensure([], () => r(require('@/views/errors/index')), 'errors')

Vue.use(Router)
export default new Router({
  routes: [
    {
      path: '/',
      component: login,
      meta: {
        requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
      }
    },
    {
      path: '/errors',
      component: errors,
      meta: {
        index: 0,
        title: '错误页面'
      }
    },
    // 个人中心
    ...personalCenter
  ]
})
