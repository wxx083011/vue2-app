<template>
  <div class="login wrap">
    <div class="login-top center">个人中心</div>123
  </div>
</template>
<script>
export default {
  name: 'login',
  components: {},
  data () {
    return {}
  },
  created () {
    let i = 1
    console.log(i)
  },
  methods: {
  }
}
</script>
<style lang="scss" scoped>
.login {
  &-top {
    width: 10rem;
    height: 1.333333rem;
    background: saddlebrown;
    font-size: 0.373333rem;
    color: #fff;
  }
}
</style>
