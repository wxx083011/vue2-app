<template>
 <div>绑定信息
 </div>
</template>

<script>

export default {
  name: 'bindInfo',
  data () {
    return {
    }
  },
  components: {
  },
  created () {
  },
  methods: {
  }
}
</script>
<style >
 </style>
