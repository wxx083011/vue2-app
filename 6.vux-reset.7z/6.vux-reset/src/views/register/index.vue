<template>
  <div class="kb-wrap register-wrap">
  </div>
</template>
<script>
export default {
  name: 'register',
  components: {},
  data () {
    return {
    }
  },

  created () {
  },
  methods: {
  }
}
</script>
<style lang="scss" scoped>
.register-wrap {
}
</style>
