<template>
 <div>
   token过期页面
   <div @click="$router.push({path: `/personalCenter`})">个人中心</div>

 </div>
</template>

<script>

export default {
  name: 'errors',
  data () {
    return {
    }
  },
  components: {
  },
  created () {
  },
  methods: {
  }
}
</script>
<style >
 </style>
