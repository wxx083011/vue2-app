<template>
 <div>个人信息完善
 </div>
</template>

<script>

export default {
  name: 'personalCenter',
  data () {
    return {
    }
  },
  components: {
  },
  created () {
  },
  methods: {
  }
}
</script>
<style >
 </style>
