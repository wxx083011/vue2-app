import Vue from 'vue'
import Router from 'vue-router'

import personalCenter from './personalCenter'
const register = r => require.ensure([], () => r(require('@/views/register/index')), 'register')
const errors = r => require.ensure([], () => r(require('@/views/errors/index')), 'errors')

Vue.use(Router)
const router = new Router({
  routes: [
    {
      path: '/',
      component: register,
      meta: {
        requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
      }
    },
    {
      path: '/errors',
      component: errors,
      meta: {
        index: 0,
        title: '错误页面'
      }
    },
    // 个人中心
    ...personalCenter
  ]
})

router.beforeEach((to, from, next) => {
  if (to.meta.title) document.title = to.meta.title

  if (to.matched.some(record => record.meta.requireAuth)) { // 判断该路由是否需要登录权限
    let token = localStorage.getItem('token') || ''
    if (!token) {
      localStorage.setItem('token', '1221')
      next()
    } else {
      next()
    }
  } else {
    next()
  }
  next()
})
router.afterEach(to => {

})
export default router
