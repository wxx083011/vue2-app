const personalCenter = r => require.ensure([], () => r(require('@/views/personalCenter/index')), 'personalCenter')
const bindInfo = r => require.ensure([], () => r(require('@/views/personalCenter/bindInfo')), 'bindInfo')
const personalDetails = r => require.ensure([], () => r(require('@/views/personalCenter/personalDetails')), 'personalDetails')

export default [
  {
    path: '/personalCenter',
    name: 'personalCenter',
    component: personalCenter,
    meta: {
      title: '个人中心'
    }
  },
  {
    path: '/bindInfo',
    name: 'bindInfo',
    component: bindInfo,
    meta: {
      title: '绑定信息'
    }
  },
  {
    path: '/personalDetails',
    name: 'personalDetails',
    component: personalDetails,
    meta: {
      title: '完善信息'
    }
  }]
